#ifndef DEMO_H
#define DEMO_H

#include<string>


class Demo{
public:
    void sayHello(const std::string& name);
    void print();
private:
};


#endif // DEMO
