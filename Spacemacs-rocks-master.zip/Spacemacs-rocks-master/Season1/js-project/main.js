
var math = require("./lib/math.js");
var test = require("./lib/test.js");
var fs = require("fs");
var hello;


console.log(math.sum(1, 2));
console.log(math.substract(2, 1));
console.log("hello");
console.log("workd");
test.test();
