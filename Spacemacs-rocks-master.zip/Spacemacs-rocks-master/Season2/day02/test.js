var myfunc = function() {
    console.log("hello world");
};

myfunc();

// nodejs-repl-send-buffer 
